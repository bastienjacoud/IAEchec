//
// Created by natjo on 13/04/2017.
//

#ifndef ECHECIA_FOU_H
#define ECHECIA_FOU_H


class Fou {
public:
    Fou();
    virtual ~Fou();
    bool DeplacementOK(int depX, int depY);
    protected:
    private:
};


#endif //ECHECIA_FOU_H
