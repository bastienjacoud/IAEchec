#include "Roi.h"

Roi::Roi()
{
    //ctor
}

Roi::~Roi()
{
    //dtor
}
