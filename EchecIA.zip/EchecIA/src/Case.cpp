#include <array>
#include <iostream>
#include "../include/Case.h"

using namespace std;

Case::Case()
{
    this->m_piece = NULL;
    //ctor
}

Case::Case(Piece p)
{
    this->m_piece = new Piece(p);
}

Case::~Case()
{
    //dtor
}

void Case::Afficher()
{
    if(this->Getpiece() == NULL)
        cout<<" __ ";
    else
        m_piece->Afficher();
}

Case* Case::CopieCase()
{
    Case* c = new Case();
    if(this->Getpiece() == NULL)
        c->m_piece = NULL;
    else
        c->Setpiece(this->Getpiece()->CopiePiece());
    return c;
}

Piece* Case::Move()
{
    Piece *p = m_piece;
    m_piece = NULL;
    return p;
}

void Case::ChangePiece(Piece* p)
{

}

