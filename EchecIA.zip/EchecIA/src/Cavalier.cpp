#include "Cavalier.h"

Cavalier::Cavalier()
{
    //ctor
}

Cavalier::~Cavalier()
{
    //dtor
}
