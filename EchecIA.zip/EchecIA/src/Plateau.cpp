#include<iostream>
#include <windows.h>
#include "../include/Plateau.h"

using namespace std;



Plateau::Plateau()
{
    //Initialisation de la grille
    for(int i=0; i<8; i++)
        for(int j=0;j<8;j++)
        {
            this->m_plateau[i][j] = new Case();
        }

    //placement des pions noirs
    this->m_plateau[0][0]->Setpiece( new Tour(1) );
    this->m_plateau[0][2]->Setpiece( new Fou(1) );//0 2
    this->m_plateau[0][4]->Setpiece( new Roi(1) );
    this->m_plateau[0][6]->Setpiece( new Cavalier(1) );
    this->m_plateau[1][1]->Setpiece( new Pion(1) );
    this->m_plateau[1][3]->Setpiece( new Pion(1) );
    this->m_plateau[1][5]->Setpiece( new Pion(1) );
    this->m_plateau[1][7]->Setpiece( new Pion(1) );
    this->m_plateau[2][0]->Setpiece( new Pion(1) );//2 0
    this->m_plateau[2][2]->Setpiece( new Pion(1) );
    this->m_plateau[2][4]->Setpiece( new Pion(1) );
    this->m_plateau[2][6]->Setpiece( new Pion(1) );


    //placement des pions blancs
    this->m_plateau[7][0]->Setpiece( new Tour(2) );
    this->m_plateau[7][2]->Setpiece( new Fou(2) );
    this->m_plateau[7][4]->Setpiece( new Roi(2) );
    this->m_plateau[7][6]->Setpiece( new Cavalier(2) );
    this->m_plateau[6][1]->Setpiece( new Pion(2) );
    this->m_plateau[6][3]->Setpiece( new Pion(2) );
    this->m_plateau[6][5]->Setpiece( new Pion(2) );
    this->m_plateau[6][7]->Setpiece( new Pion(2) );//6 7
    this->m_plateau[5][0]->Setpiece( new Pion(2) );//5 0
    this->m_plateau[5][2]->Setpiece( new Pion(2) );
    this->m_plateau[5][4]->Setpiece( new Pion(2) );
    this->m_plateau[5][6]->Setpiece( new Pion(2) );

    for(int i=0;i<24;i++)
        this->piecesPrisent[i] = new Piece();

    for(int i=0;i<768;i++)
        for(int j=0;j<4;j++)
            pos_possible[i][j] = -1;

}

Plateau::Plateau(Plateau& p)
{
    for(int i=0;i<768;i++)
        for(int j=0;j<4;j++)
        {
            this->pos_possible[i][j] = p.pos_possible[i][j];
        }

    this->np = p.np;
    for(int i=0;i<24;i++)
        this->piecesPrisent[i] = new Piece(*piecesPrisent[i]);

    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            m_plateau[i][j] = new Case(*p.Getplateau(i,j).Getpiece());
}


Plateau* Plateau::CopiePlateau()
{
    Plateau* p = new Plateau();

    return p;
}


Plateau::~Plateau()
{
    //dtor
}

void Plateau::Setplateau(Case plateau[8][8])
{
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            *m_plateau[i][j] = plateau[i][j];
}

void Plateau::AjoutePiecePrise(Piece* p)
{
    for(int i=0;i<24;i++)
        if(this->piecesPrisent[i] != NULL)
        {
            if(this->piecesPrisent[i]->getType() == 'I')
            {
                this->piecesPrisent[i] = p;
                return;
            }
        }

}

void Plateau::SupprimePiecePrise(Piece p)
{
    for(int i=0;i<24;i++)
        if(this->piecesPrisent[i] != NULL)
            if(this->piecesPrisent[i]->getType() == p.getType())
                this->piecesPrisent[i] = NULL;
}

void Plateau::AffichePiecePrise()
{
    for(int i=0;i<24;i++)
        if(this->piecesPrisent[i] != NULL)
            cout<<this->piecesPrisent[i]->getType()<<endl;
}

/*
void Plateau::SetPiece(int i, int j, Piece* p)
{
    this->m_plateau[0][0]->Setpiece(p);
}
*/
void Plateau::Afficher()
{
    for(int i=0;i<8;i++)
    {
        for(int j=0;j<8;j++)
        {
            this->Getplateau(i,j).Afficher();
        }
        cout<<endl<<endl;
    }
}

int Plateau::prendrePiece(int xdep, int ydep, int xarrivee, int yarrivee)//Fonction pour prendre une piece adverse
{
    if(this->Getplateau(xarrivee, yarrivee).Getpiece()->GetCouleur() != this->Getplateau(xdep, ydep).Getpiece()->GetCouleur())
    {
        int tabt;
        int tab[16];
        for(int i=0;i<16;i++)
            tab[i] = 0;
        if(this->Getplateau(xdep, ydep).Getpiece()->PriseOK(xarrivee - xdep,yarrivee - ydep, tab, tabt) == 1)
        {
            if(tabt == 0)//Si pas de case entre case arriv�e et case d�part
            {
                this->AjoutePiecePrise(this->Getplateau(xarrivee, yarrivee).Getpiece());
                this->Getplateau(xdep, ydep).Getpiece()->SetPremierCoup(0);
                this->Getplateau(xarrivee, yarrivee).Setpiece(  this->Getplateau(xdep, ydep).Move() );
                return 1;
            }
            else
            {
                int b=1;
                for(int i=0;i<tabt;i+=2)
                {
                    if(this->Getplateau(xdep + tab[i+1], ydep + tab[i]).Getpiece() != NULL)//S'il y a une pi�ce entre la case de d�part et d'arriv�
                    {
                        b=0;
                    }

                }
                if(b==1)
                {
                    this->AjoutePiecePrise(this->Getplateau(xarrivee, yarrivee).Getpiece());
                    this->Getplateau(xdep, ydep).Getpiece()->SetPremierCoup(0);
                    this->Getplateau(xarrivee, yarrivee).Setpiece(  this->Getplateau(xdep, ydep).Move() );
                    return 1;
                }
                else if(b==0)
                {
                    return 0;
                }
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
    return 0;
}

int Plateau::DeplacerPiece(int xdep, int ydep, int xarrivee, int yarrivee)
{
    //x -> lignes
    //y colonnes
    if(this->Getplateau(xarrivee, yarrivee).Getpiece() == NULL)//Si on bouge sur une case vide
    {
        int tabt;
        int tab[16];
        for(int i=0;i<16;i++)
            tab[i] = 0;
        if(this->Getplateau(xdep, ydep).Getpiece()->DeplacementOK(xarrivee - xdep,yarrivee - ydep, tab, tabt) == 1)
        {

            if(tabt == 0)//Si pas de case entre case arriv�e et case d�part
            {
                this->Getplateau(xdep, ydep).Getpiece()->SetPremierCoup(0);
                this->Getplateau(xarrivee, yarrivee).Setpiece( this->Getplateau(xdep, ydep).Move() );
                return 1;
            }
            else
            {

                int b=1;
                for(int i=0;i<tabt;i+=2)
                {
                    if(this->Getplateau(xdep + tab[i+1], ydep + tab[i]).Getpiece() != NULL)//S'il y a une pi�ce entre la case de d�part et d'arriv�
                        b=0;
                }
                if(b==1)
                {
                    this->Getplateau(xdep, ydep).Getpiece()->SetPremierCoup(0);
                    this->Getplateau(xarrivee, yarrivee).Setpiece(  this->Getplateau(xdep, ydep).Move() );
                    return 1;
                }
                else if(b==0)
                {
                    return 0;
                }
            }
        }
        else
        {
            //cout<<"test"<<endl;
            return 0;
        }

    }
    else
        return this->prendrePiece(xdep, ydep, xarrivee, yarrivee);
    return 0;
}

int Plateau::TestFinJeu()
{
    //la partie se termine lorsque le roi adverse est prit ou en echec et mat
    for(int i=0;i<24;i++)
    {
        if(piecesPrisent[i] != NULL)
        {
            if(piecesPrisent[i]->getType() == 'R')
            {
                if (piecesPrisent[i]->GetCouleur() == 1)
                    {
                        cout<<"le joueur 2 a gagne."<<endl;
                        return 2;
                    }
                if (piecesPrisent[i]->GetCouleur() == 2)
                    {
                        cout<<"le joueur 1 a gagne."<<endl;
                        return 1;
                    }
            }
        }
    }
    return 0;
}

void Plateau::TestPionArrive()
{
    char c;
    for(int i=0;i<8;i++)
    {
        if(this->Getplateau(0,i).Getpiece() != NULL)
            if(this->Getplateau(0,i).Getpiece()->getType() == 'P')
            {
                int b=0;
                while(b==0)
                {
                    cout<<"Par quelle piece remplacer votre pion?(T, C ou F)"<<endl;
                    cin>>c;
                    if(c == 'T'){
                        this->Getplateau(0,i).Setpiece(new Tour(2));
                        b=1;
                    }

                    if(c == 'C'){
                        this->Getplateau(0,i).Setpiece(new Cavalier(2));
                        b=1;
                    }

                    if(c == 'F'){
                        this->Getplateau(0,i).Setpiece(new Fou(2));
                        b=1;
                    }
/*                    for(int k=0;k<24;k++)
                    {
                        if(this->piecesPrisent[k] != NULL)
                        {
                            if((this->piecesPrisent[k]->getType() == c) && (this->piecesPrisent[k]->GetCouleur() == 2))
                            {
                                b=1;
                                this->Getplateau(0,i).Setpiece(this->piecesPrisent[k]);
                                this->piecesPrisent[k] = NULL;
                            }
                        }
                        else // si le joueur ne s'est fait prendre aucune piece
                            if(c == 'P')
                                b=1;
                    }
*/                    if(b==0)
                    {
                        //cout<<"Choisissez une pièce que vous avez perdu !"<<endl;
                        cout<<"Vous avez le choix seulement entre T, C et F !"<<endl;
                    }
                }
            }

        if(this->Getplateau(7,i).Getpiece() != NULL)
            if(this->Getplateau(7,i).Getpiece()->getType() == 'P')
            {
                int b=0;
                while(b==0)
                {
                    cout<<"Par quelle piece remplacer votre pion?(T, C ou F)"<<endl;
                    cin>>c;
                    if(c == 'T'){
                        this->Getplateau(7,i).Setpiece(new Tour(1));
                        b=1;
                    }

                    if(c == 'C'){
                        this->Getplateau(7,i).Setpiece(new Cavalier(1));
                        b=1;
                    }

                    if(c == 'F'){
                        this->Getplateau(7,i).Setpiece(new Fou(1));
                        b=1;
                    }
/*                    for(int k=0;k<24;k++)
                    {
                        if(this->piecesPrisent[k] != NULL)
                            if((this->piecesPrisent[k]->getType() == c) && (this->piecesPrisent[k]->GetCouleur() == 1))
                            {
                                b=1;
                                this->Getplateau(7,i).Setpiece(this->piecesPrisent[k]);
                                this->piecesPrisent[k] = NULL;
                            }
                    }
*/                    if(b==0)
                    {
                        //cout<<"Choisissez une pièce que vous avez perdu !"<<endl;
                        cout<<"Vous avez le choix seulement entre T, C et F !"<<endl;
                    }
                }
            }
    }
}



/*
        IMPLEMENTATION DE L'IA
*/

int Plateau::Evaluation(Plateau& plateau)
{
    //cout<<"test"<<endl;
    return 1;
}

int Plateau::alphaBetaMax(Plateau& plateau, int& alpha, int& beta, int prof )//plateau modifié
{
    Piece* prise;//Sert si l'IA "prend" une piece à la remettre
    if ( prof == 0 )
        return Evaluation(plateau);

    int tabDepl = deplacementPossible(2);//l'IA jouera toujours avec la couleur 2

    int positions[tabDepl][4];
    for(int i=0;i<tabDepl;i++)
        for(int j=0;j<4;j++)
            positions[i][j] = pos_possible[i][j];

    for (int i = 0; i< tabDepl; i++)
    {
      Plateau plateau_modifie = plateau; //copie du plateau

      if(plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece() == NULL)
            prise = NULL;
      else
            prise = plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece();

      //On joue le coup
      plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Setpiece( plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Move() );
      plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece()->SetPremierCoup(0);
      plateau_modifie.Afficher();
      //Sleep(1000);
      //On calcule le score
      int score = alphaBetaMin(plateau_modifie, alpha, beta, prof - 1 );

      //On annule le coup
      plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Setpiece( plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Move() );
      plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Getpiece()->SetPremierCoup(1);

      if(prise != NULL)
            plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Setpiece( prise );

      plateau_modifie.Afficher();
      //Sleep(1000);

      if( score >= beta )
         return beta;   // fail hard beta-cutoff
      if( score > alpha )
         alpha = score; // alpha acts like max in MiniMax
    }
    return alpha;
}

int Plateau::alphaBetaMin(Plateau& plateau, int& alpha, int& beta, int prof )
{
    Piece* prise;//Sert si l'IA "prend" une piece à la remettre
    if ( prof == 0 )
        return - Evaluation(plateau);

    int tabDepl = deplacementPossible(2);//l'IA jouera toujours avec la couleur 2
    //cout<<tabDepl<<endl;
    int positions[tabDepl][4];
    for(int i=0;i<tabDepl;i++)
        for(int j=0;j<4;j++)
        {
            positions[i][j] = pos_possible[i][j];
        }

    cout<<"Depart 1 "<<positions[0][0]<<positions[0][1]<<endl;
    cout<<"Arrivee 1 "<<positions[0][2]<<positions[0][3]<<endl;

    cout<<"Depart 2 "<<positions[1][0]<<positions[1][1]<<endl;
    cout<<"Arrivee 2 "<<positions[1][2]<<positions[1][3]<<endl;
    for (int i = 0; i< tabDepl; i++)
    {
      //cout<<"test"<<endl;
      Plateau plateau_modifie = plateau; //copie du plateau

      if(plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece() == NULL)
            prise = NULL;
      else
            prise = plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece();

      //On joue le coup
      plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Setpiece( plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Move() );
      plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Getpiece()->SetPremierCoup(0);

      plateau_modifie.Afficher();
      //Sleep(1000);

      //On calcule le score
      int score = alphaBetaMax(plateau_modifie, alpha, beta, prof - 1 );

      cout<<"test1"<<endl;
      //On annule le coup
      plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Setpiece( plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Move() );
      plateau_modifie.Getplateau(positions[i][0], positions[i][1]).Getpiece()->SetPremierCoup(1);

      if(prise != NULL)
            plateau_modifie.Getplateau(positions[i][2], positions[i][3]).Setpiece( prise );

      cout<<"test2"<<endl;
      plateau_modifie.Afficher();
      //Sleep(1000);

      if( score <= alpha )
      {cout<<plateau_modifie.pos_possible[0][0]<<endl;
          return alpha; // fail hard alpha-cutoff
      }

      if( score < beta )
         beta = score; // beta acts like min in MiniMax
    }
    return beta;
}


void Plateau::lancerIA(Plateau plateau, int prof)
{
    int maximum = -10000;
    int minimum = 10000;
    Piece* prise;//Sert si l'IA "prend" une piece à la remettre
    int xdep,ydep,xarr,yarr;

    int tabDepl = deplacementPossible(2);//l'IA jouera toujours avec la couleur 2
    int positions[tabDepl][4];
    for(int i=0;i<tabDepl;i++)
        for(int j=0;j<4;j++)
            positions[i][j] = pos_possible[i][j];
    for (int i = 0; i< tabDepl; i++)
    {
        Plateau* plateau_modifie = new Plateau(plateau); //copie du plateau
        cout<<plateau_modifie->pos_possible[0][0]<<endl;
        cout<<plateau.pos_possible[0][0]<<endl;
        //cout<<"test"<<endl;
        //plateau.Afficher();
        //cout<<pos_possible[i][0]<<pos_possible[i][1]<<pos_possible[i][2]<<pos_possible[i][3]<<endl;
        //cout<<plateau.Getplateau(pos_possible[i][0],pos_possible[i][1]).Getpiece()->getType();
        //On joue le coup
        //cout<<plateau.DeplacerPiece(pos_possible[i][0],pos_possible[i][1],pos_possible[i][2],pos_possible[i][3]);
        //cout<<plateau.DeplacerPiece(2,5,2,3);
        //cout<<plateau.Getplateau(pos_possible[i][2],pos_possible[i][3]).Getpiece()->getType();
        if(plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Getpiece() == NULL)
            prise = NULL;
        else
            prise = plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Getpiece();
        plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Setpiece( plateau_modifie->Getplateau(positions[i][0], positions[i][1]).Move() );
        plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Getpiece()->SetPremierCoup(0);


        plateau.Afficher();
        Sleep(1000);

        plateau_modifie->Afficher();
        Sleep(1000);

        //cout<<"test"<<endl;
        //On calcule le score
        int score = alphaBetaMin(*plateau_modifie, maximum, minimum, prof - 1 );

        if((score > maximum)/* || ((tmp == maximum) && ((rand() % 2) == 0))*/)
        {
            //cout<<"test"<<endl;
            maximum = score;
            xdep = positions[i][0];
            ydep = positions[i][1];
            xarr = positions[i][2];
            yarr = positions[i][3];
        }
        //cout<<"test1"<<endl;
        //cout<<pos_possible[i][0]<<pos_possible[i][1]<<pos_possible[i][2]<<pos_possible[i][3]<<endl;
        //cout<<Getplateau(pos_possible[i][2],pos_possible[i][3]).Getpiece()->getType();
        //On annule le coup
        //plateau.DeplacerPiece(pos_possible[i][2],pos_possible[i][3],pos_possible[i][0],pos_possible[i][1]);
        //cout<<"test2"<<endl;
        plateau_modifie->Getplateau(positions[i][0], positions[i][1]).Setpiece( plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Move() );
        plateau_modifie->Getplateau(positions[i][0], positions[i][1]).Getpiece()->SetPremierCoup(1);
        if(prise != NULL)
            plateau_modifie->Getplateau(positions[i][2], positions[i][3]).Setpiece( prise );
        plateau_modifie->Afficher();
        //cout<<"test"<<endl;
        //Sleep(1000);

    }

    //cout<<xdep<<ydep<<xarr<<yarr<<"test"<<endl;
    cout<<"Deplacement final :"<<endl;

    if(this->Getplateau(xarr, yarr).Getpiece() == NULL)
    {
        this->Getplateau(xarr, yarr).Setpiece( this->Getplateau(xdep, ydep).Move() );
        this->Getplateau(xarr, yarr).Getpiece()->SetPremierCoup(0);
    }

    else
    {
        this->AjoutePiecePrise(this->Getplateau(xarr, yarr).Getpiece());
        this->Getplateau(xarr, yarr).Setpiece( this->Getplateau(xdep, ydep).Move() );
        this->Getplateau(xarr, yarr).Getpiece()->SetPremierCoup(0);
    }

}

int Plateau::deplacementPossible(int couleur) // Fonctionnelle
{
    int n = 0;
    for(int i = 0; i < 8; i++)
    {
        for(int j = 0; j < 8; j++)
        {
            if(this->Getplateau(i, j).Getpiece() != NULL && this->Getplateau(i,j).Getpiece()->GetCouleur() == couleur)
            {
                for(int a = 0; a < 8; a++)
                {
                    for(int b = 0; b < 8; b++)
                    {
                        if(this->Getplateau(a, b).Getpiece() == NULL)//Si on bouge sur une case vide
                        {
                            int tabt;
                            int tab[16];
                            for(int k=0;k<16;k++)
                                tab[k] = 0;
                            if(this->Getplateau(i, j).Getpiece()->DeplacementOK(a - i,b - j, tab, tabt) == 1)
                            {

                                if(tabt == 0)//Si pas de case entre case arriv�e et case d�part
                                {
                                    //cout<<n<<endl;
                                    //cout<<"n1 :"<<n<<endl;
                                    pos_possible[n][0] = i;
                                    pos_possible[n][1] = j;
                                    pos_possible[n][2] = a;
                                    pos_possible[n][3] = b;

                                    n++;
                                    /*
                                    cout<< pos_possible[n-1][0] <<endl;
                                    cout<< pos_possible[n-1][1] <<endl;
                                    cout<< pos_possible[n-1][2] <<endl;
                                    cout<< pos_possible[n-1][3] <<endl;
                                    */
                                    //Sleep(100000);
                                }
                                else
                                {
                                    int m=1;
                                    for(int k=0;k<tabt;k+=2)
                                    {
                                        if(this->Getplateau(i + tab[k+1], j + tab[k]).Getpiece() != NULL)//S'il y a une pi�ce entre la case de d�part et d'arriv�
                                            m=0;
                                    }
                                    if(m==1)
                                    {
                                        //cout<<n<<endl;
                                        //cout<<"n2 :"<<n<<endl;
                                        pos_possible[n][0] = i;
                                        pos_possible[n][1] = j;
                                        pos_possible[n][2] = a;
                                        pos_possible[n][3] = b;

                                        n++;
                                        /*
                                        cout<< pos_possible[n-1][0] <<endl;
                                        cout<< pos_possible[n-1][1] <<endl;
                                        cout<< pos_possible[n-1][2] <<endl;
                                        cout<< pos_possible[n-1][3] <<endl;
                                        */
                                    }
                                }
                            }

                        }
                        else if(this->Getplateau(a, b).Getpiece()->GetCouleur() != this->Getplateau(i, j).Getpiece()->GetCouleur())
                        {
                            int tabt;
                            int tab[16];
                            for(int k=0;k<16;k++)
                                tab[k] = 0;
                            if(this->Getplateau(i, j).Getpiece()->PriseOK(a - i,b - j, tab, tabt) == 1)
                            {
                                if(tabt == 0)//Si pas de case entre case arriv�e et case d�part
                                {
                                    //cout<<n<<endl;
                                    //cout<<"n3 :"<<n<<endl;
                                    pos_possible[n][0] = i;
                                    pos_possible[n][1] = j;
                                    pos_possible[n][2] = a;
                                    pos_possible[n][3] = b;

                                    n++;
                                    /*
                                    cout<< pos_possible[n-1][0] <<endl;
                                    cout<< pos_possible[n-1][1] <<endl;
                                    cout<< pos_possible[n-1][2] <<endl;
                                    cout<< pos_possible[n-1][3] <<endl;
*/
                                }
                                else
                                {
                                    int m=1;
                                    for(int k=0;k<tabt;k+=2)
                                    {
                                        if(this->Getplateau(i + tab[k+1], j + tab[k]).Getpiece() != NULL)//S'il y a une pi�ce entre la case de d�part et d'arriv�
                                        {
                                            m=0;
                                        }

                                    }
                                    if(m==1)
                                    {
                                        //cout<<n<<endl;
                                        //cout<<"n4 :"<<n<<endl;
                                        pos_possible[n][0] = i;
                                        pos_possible[n][1] = j;
                                        pos_possible[n][2] = a;
                                        pos_possible[n][3] = b;

                                        n++;
                                        /*
                                        cout<< pos_possible[n-1][0] <<endl;
                                        cout<< pos_possible[n-1][1] <<endl;
                                        cout<< pos_possible[n-1][2] <<endl;
                                        cout<< pos_possible[n-1][3] <<endl;
                                        */
                                    }
                                }
                            }
                        }
                    //Sleep(100);
                    }

                }
            }
        }
    }
    return n;
}



int main()
{
    Plateau* p = new Plateau();
    int xd;
    int yd;
    int xf;
    int yf;
    int joueurcourant=1;
    // 1 -> joueur
    // 2 -> IA
    int chgtpiece;

    while(p->TestFinJeu() == 0)
    //while(true)
    {
        if(joueurcourant == 1)
        {
            chgtpiece = 0;
            cout<<"C'est au joueur "<<joueurcourant<<" de jouer."<<endl;

            p->Afficher();

            cout << "ligne de la piece a bouger : \n"; cin >> xd;xd--;
            cout << "colonne de la piece a bouger : \n"; cin >> yd;yd--;
            while((xd>=8 || xd<0 || yd>=8 || yd<0) || p->Getplateau(xd,yd).Getpiece() == NULL || joueurcourant != p->Getplateau(xd,yd).Getpiece()->GetCouleur())
            {
                cout<< "Coordonnees de la piece a deplacer invalides. Veuillez reessayer."<<endl;
                p->Afficher();
                cout << "ligne de la piece a bouger : \n"; cin >> xd;xd--;
                cout << "colonne de la piece a bouger : \n"; cin >> yd;yd--;
            }


            cout << "ligne ou deplacer la piece(0 0 pour changer de piece) : \n"; cin >> xf;xf--;
            cout << "colonne ou deplacer la piece(0 0 pour changer de piece) : \n"; cin >> yf;yf--;
            if(xf == -1 && yf == -1)
                chgtpiece = 1;

            while((chgtpiece == 0) && ((xf>=8 || xf<0 || yf>=8 || yf<0) || (p->DeplacerPiece(xd, yd, xf, yf) == 0)) )
            {

                cout<< "Coordonnees de la case d'arrivee invalides. Veuillez reessayer."<<endl;
                p->Afficher();
                cout << "ligne ou deplacer la piece(0 0 pour changer de piece) : \n"; cin >> xf;xf--;
                cout << "colonne ou deplacer la piece(0 0 pour changer de piece) : \n"; cin >> yf;yf--;
                if(xf == -1 && yf == -1)
                    chgtpiece = 1;
            }

            if(chgtpiece==0)
            {
                joueurcourant = 2;
            }

            //p->AffichePiecePrise();
            p->TestPionArrive();
        }
        else if(joueurcourant == 2)
        {
            //Sleep(10000);
            p->lancerIA(*p,2);
            //p->AffichePiecePrise();
            p->TestPionArrive();

            p->Afficher();

            joueurcourant = 1;
        }


    }

    return 0;
}
